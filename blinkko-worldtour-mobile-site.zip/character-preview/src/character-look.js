import * as THREE from "../vendor/three.module.js";

export const PALETTE = Object.freeze({
  coat: 0xee7d18, cream: 0xffe6c4, coral: 0xf1774f, forehead: 0xed6948, eyes: 0x181411,
});
export const LAMP_STATES = Object.freeze({
  idle: { color: 0xffd984, label: "WARM", duration: 0 },
  reward: { color: 0x48f39c, label: "REWARD", duration: 2.8 },
  impact: { color: 0xff4658, label: "IMPACT", duration: 1.8 },
  boost: { color: 0x40caff, label: "BOOST", duration: 2.8 },
  off: { color: 0x53534e, label: "OFF", duration: 0 },
});
const smooth = (a, b, value) => THREE.MathUtils.smoothstep(value, a, b);

// Regions in the normalized, forward-X reference pose. The face is a pair
// of rounded brow/cheek lobes, not a horizontal white band across the skull.
export function getCoatRegions({ x, y, z }) {
  const side = Math.abs(z);
  const brow = 0.024 + 0.080 * Math.exp(-(((side - 0.18) / 0.13) ** 2))
    - 0.26 * smooth(0.27, 0.47, side);
  const face = smooth(0.67, 0.90, x)
    * (1 - smooth(brow - 0.027, brow + 0.027, y))
    * smooth(-0.37, -0.23, y);
  // A small upper-neck marking only: no full-height white stripe down the
  // side of the neck, and no cream reaching the ear roots/back of the skull.
  const neck = smooth(0.25, 0.29, x) * (1 - smooth(0.34, 0.40, x))
    * smooth(-0.04, 0.035, y) * (1 - smooth(0.23, 0.29, y));
  // Narrow, curved cream ring below the ear: connects the small rear-neck
  // marking to the muzzle without repainting the upper side of the skull.
  const ringCenter = 0.015 - 0.16 * smooth(0.30, 0.94, x);
  const sideRing = smooth(0.27, 0.33, x) * (1 - smooth(0.94, 1.02, x))
    * smooth(0.12, 0.22, side)
    * (1 - smooth(0.025, 0.060, Math.abs(y - ringCenter)));
  const belly = (1 - smooth(-0.27, -0.18, y)) * (1 - smooth(0.10, 0.21, side))
    * smooth(-0.68, -0.42, x) * (1 - smooth(0.28, 0.45, x));
  return { face, neck, sideRing, belly, cream: Math.max(face, neck, sideRing, belly * 0.88) };
}

// A small tapered coral-red forelock painted directly on the animated scalp.
// It follows the surface; no floating cones or detached decoration are added.
export function getForeheadTuftMask({x, y, z}) {
  const t = smooth(0.10, 0.40, y);
  const halfWidth = 0.025 + 0.063 * Math.pow(Math.max(0, Math.sin(Math.PI * t)), 0.75);
  return smooth(0.73, 0.92, x) * smooth(0.105, 0.155, y)
    * (1 - smooth(0.34, 0.40, y))
    * (1 - smooth(halfWidth * 0.45, halfWidth, Math.abs(z))) * 0.92;
}

// Paint in the aligned reference pose, then store color on the vertices so all
// regions stay attached to the original skinned surface throughout animation.
export function paintCharacter(character, flightRoot, gradientMap) {
  // SkinnedMesh.updateMatrixWorld also refreshes its attached bind inverse after scaling.
  flightRoot.updateMatrixWorld(true);
  const coat = new THREE.Color(PALETTE.coat);
  const cream = new THREE.Color(PALETTE.cream);
  const coral = new THREE.Color(PALETTE.coral);
  const forehead = new THREE.Color(PALETTE.forehead);
  const point = new THREE.Vector3();
  const normal = new THREE.Vector3();
  const color = new THREE.Color();
  const frameInverse = flightRoot.matrixWorld.clone().invert();
  const stats = { paintedVertices: 0, creamVertices: 0, coralVertices: 0, foreheadVertices: 0 };
  character.traverse((mesh) => {
    if (!mesh.isMesh) return;
    const originals = Array.isArray(mesh.material) ? mesh.material : [mesh.material];
    const isBody = originals.some((material) => material.name === "skin");
    if (isBody) {
      mesh.geometry = mesh.geometry.clone();
      const positions = mesh.geometry.attributes.position;
      const normals = mesh.geometry.attributes.normal;
      const colors = new Float32Array(positions.count * 3);
      const toFlight = new THREE.Matrix4().multiplyMatrices(frameInverse, mesh.matrixWorld);
      const normalMatrix = new THREE.Matrix3().getNormalMatrix(toFlight);
      for (let i = 0; i < positions.count; i++) {
        mesh.getVertexPosition(i, point).applyMatrix4(toFlight);
        normal.fromBufferAttribute(normals, i).applyNormalMatrix(normalMatrix);
        const { x, y, z } = point;
        const az = Math.abs(z);
        const { cream: white } = getCoatRegions(point);
        color.copy(coat).lerp(cream, white);
        const cheekDistance = ((az - 0.235) / 0.095) ** 2 + ((y + 0.10) / 0.078) ** 2;
        const cheek = (1 - smooth(0.15, 1.25, cheekDistance)) * smooth(0.94, 1.09, x) * white;
        const ear = smooth(0.31, 0.44, az) * smooth(0.19, 0.33, y)
          * smooth(0.43, 0.68, x) * smooth(-0.1, 0.7, normal.x);
        const coralMask = Math.max(cheek * 0.82, ear * 0.72);
        color.lerp(coral, coralMask);
        const forelock = getForeheadTuftMask(point);
        color.lerp(forehead, forelock);
        if (forelock > 0.2) stats.foreheadVertices++;
        color.toArray(colors, i * 3);
        stats.paintedVertices++;
        if (white > 0.65) stats.creamVertices++;
        if (coralMask > 0.25) stats.coralVertices++;
      }
      mesh.geometry.setAttribute("color", new THREE.BufferAttribute(colors, 3));
    }
    const materials = originals.map((source) => {
      const name = source.name.toLowerCase();
      let material;
      if (name.includes("tail light")) {
        material = new THREE.MeshStandardMaterial({ color: 0xffe0a0, emissive: 0xffd984, emissiveIntensity: 0.9, roughness: 0.32, toneMapped: false });
      } else if (name.includes("glass")) {
        // The GLB has a separate sleeve around the lamp. An opaque replacement
        // hides the actual emitter, so keep this shell translucent.
        material = new THREE.MeshStandardMaterial({ color: 0xfff3d5, emissive: 0xffd984, emissiveIntensity: 0.3, transparent: true, opacity: 0.28, roughness: 0.28, depthWrite: false, side: THREE.FrontSide });
      } else if (name.includes("eye") || name.includes("nose")) {
        material = new THREE.MeshStandardMaterial({ color: PALETTE.eyes, roughness: name.includes("eye") ? 0.24 : 0.5 });
      } else {
        material = new THREE.MeshToonMaterial({ color: isBody ? 0xffffff : PALETTE.coat, vertexColors: isBody, gradientMap, side: source.side });
      }
      material.name = source.name;
      return material;
    });
    mesh.material = Array.isArray(mesh.material) ? materials : materials[0];
  });
  return stats;
}

export class CenterBackCape {
  constructor(character, flightRoot, gradientMap) {
    this.flightRoot = flightRoot;
    this.bone = character.getObjectByName("Bone011");
    if (!this.bone) throw new Error("The Blinko shoulder attachment bone is missing.");
    this.root = new THREE.Group();
    this.root.name = "Blinkko Center-Back Cape Rig";
    flightRoot.add(this.root);
    this.root.matrixAutoUpdate = false;
    flightRoot.updateMatrixWorld(true);
    this.frameInverse = new THREE.Matrix4();
    this.boneInFrame = new THREE.Matrix4();
    this.restInverse = this.boneMatrix().clone().invert();
    const shoulder = flightRoot.worldToLocal(this.bone.getWorldPosition(new THREE.Vector3()));
    const body = [];
    character.traverse((object) => { if (object.isSkinnedMesh && object.material?.name === "skin") body.push(object); });
    const box = new THREE.Box3().setFromObject(character);
    const ray = new THREE.Raycaster();
    const surfaceY = (x, z, fallback) => {
      const origin = flightRoot.localToWorld(new THREE.Vector3(x, box.max.y + 0.8, z));
      const direction = new THREE.Vector3(0, -1, 0).transformDirection(flightRoot.matrixWorld);
      ray.set(origin, direction);
      const hits = ray.intersectObjects(body, false);
      return hits.length ? flightRoot.worldToLocal(hits[0].point.clone()).y : fallback;
    };
    const shoulderX = shoulder.x - 0.17;
    this.anchor = new THREE.Vector3(shoulderX, surfaceY(shoulderX, 0, shoulder.y + 0.24) + 0.025, 0);
    this.rows = 24;
    this.cols = 13;
    this.length = 1.0;
    this.halfWidth = 0.37;
    this.baseline = [];
    const positions = new Float32Array(this.rows * this.cols * 3);
    const indices = [];
    for (let r = 0; r < this.rows; r++) {
      const t = r / (this.rows - 1);
      this.baseline.push(Math.max(this.anchor.y - 0.28 * t,
        surfaceY(this.anchor.x - this.length * t, 0, this.anchor.y - 0.28 * t) + 0.045) + 0.025 * t);
      if (r === 0) this.baseline[r] = this.anchor.y;
      for (let c = 0; c < this.cols - 1 && r < this.rows - 1; c++) {
        const a = r * this.cols + c;
        indices.push(a, a + this.cols, a + 1, a + 1, a + this.cols, a + this.cols + 1);
      }
    }
    this.geometry = new THREE.BufferGeometry();
    this.geometry.setAttribute("position", new THREE.BufferAttribute(positions, 3));
    this.geometry.setIndex(indices);
    this.mesh = new THREE.Mesh(this.geometry, new THREE.MeshToonMaterial({ color: 0xc92d3f, gradientMap, side: THREE.DoubleSide }));
    this.mesh.name = "Blinkko Symmetric Red Cape";
    this.mesh.frustumCulled = false;
    this.root.add(this.mesh);
    const seamPoints = Array.from({ length: 13 }, (_, i) => {
      const u = (i / 12 - 0.5) * 2;
      return new THREE.Vector3(this.anchor.x + 0.012, this.anchor.y - 0.04 * u * u, u * 0.19);
    });
    const seam = new THREE.Mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(seamPoints), 20, 0.012, 6, false),
      new THREE.MeshToonMaterial({ color: 0x982536, gradientMap }));
    seam.name = "Centered Shoulder Seam";
    this.root.add(seam);
    this.update(0, 0, 0);
  }
  boneMatrix() {
    this.bone.updateWorldMatrix(true, false);
    this.frameInverse.copy(this.flightRoot.matrixWorld).invert();
    return this.boneInFrame.multiplyMatrices(this.frameInverse, this.bone.matrixWorld);
  }
  update(time, flutter, motionScale = 1) {
    this.root.matrix.multiplyMatrices(this.boneMatrix(), this.restInverse);
    this.root.matrixWorldNeedsUpdate = true;
    const positions = this.geometry.attributes.position;
    for (let r = 0; r < this.rows; r++) {
      const t = r / (this.rows - 1);
      const width = 0.19 + (this.halfWidth - 0.19) * Math.sin(t * Math.PI * 0.5);
      for (let c = 0; c < this.cols; c++) {
        const u = c / (this.cols - 1) * 2 - 1;
        const wave = t * (0.025 + t * 0.025 + flutter * 0.008) * Math.sin(time * 5.2 - t * 6.4 + u * 0.9) * motionScale;
        positions.setXYZ(r * this.cols + c,
          this.anchor.x - this.length * t + t * 0.018 * Math.cos(time * 4 - t * 5) * motionScale,
          this.baseline[r] - (0.04 + t * 0.025) * u * u + wave,
          u * width + t * t * 0.025 * Math.sin(time * 2.8 - t * 4) * motionScale);
      }
    }
    positions.needsUpdate = true;
    this.geometry.computeVertexNormals();
  }
}

function glowTexture() {
  const size = 64;
  const data = new Uint8Array(size * size * 4);
  for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) {
    const distance = Math.hypot((x + 0.5) / size * 2 - 1, (y + 0.5) / size * 2 - 1);
    const i = (y * size + x) * 4;
    data[i] = data[i + 1] = data[i + 2] = 255;
    data[i + 3] = Math.round(Math.max(0, 1 - distance) ** 2.2 * 255);
  }
  const texture = new THREE.DataTexture(data, size, size, THREE.RGBAFormat);
  texture.magFilter = texture.minFilter = THREE.LinearFilter;
  texture.needsUpdate = true;
  return texture;
}

export class TailLamp {
  constructor(character, flightRoot, clock = () => performance.now() * 0.001) {
    this.clock = clock;
    this.expiresAt = null;
    this.flightRoot = flightRoot;
    this.mesh = character.getObjectByName("tail_light");
    if (!this.mesh) throw new Error("The original tail-light mesh is missing.");
    this.material = this.mesh.material;
    this.shellMaterial = null;
    character.traverse((object) => { if (object.isMesh && object.material?.name === "arch_glass_01") this.shellMaterial = object.material; });
    this.mesh.geometry.computeBoundingBox();
    this.localCenter = this.mesh.geometry.boundingBox.getCenter(new THREE.Vector3());
    this.baseState = "idle";
    this.state = "idle";
    this.remaining = 0;
    this.amount = 1;
    this.color = new THREE.Color(LAMP_STATES.idle.color);
    this.targetColor = this.color.clone();
    this.glow = new THREE.Sprite(new THREE.SpriteMaterial({ map: glowTexture(), color: this.color, transparent: true, opacity: 0.3, depthWrite: false, depthTest: true, toneMapped: false }));
    this.glow.name = "Tail Lamp Soft Halo";
    this.glow.scale.setScalar(0.5);
    this.light = new THREE.PointLight(LAMP_STATES.idle.color, 0.22, 0.85, 2);
    this.light.name = "Tail Lamp Local Light";
    flightRoot.add(this.glow, this.light);
    this.position = new THREE.Vector3();
  }
  setBase(state) {
    if (!["idle", "off"].includes(state)) throw new Error("Lamp base must be idle or off.");
    this.baseState = this.state = state;
    this.remaining = 0;
    this.expiresAt = null;
  }
  trigger(event) {
    if (!["reward", "impact", "boost"].includes(event)) throw new Error(`Unknown lamp event: ${event}`);
    this.state = event;
    this.remaining = LAMP_STATES[event].duration;
    this.expiresAt = this.clock() + this.remaining;
  }
  update(dt, time, motionScale = 1) {
    if (this.expiresAt !== null) {
      this.remaining = Math.max(0, this.expiresAt - this.clock());
      if (this.remaining === 0) {
        this.state = this.baseState;
        this.expiresAt = null;
      }
    }
    const active = this.state !== "off";
    const event = !["idle", "off"].includes(this.state);
    const blend = 1 - Math.exp(-dt * 11);
    this.targetColor.set(LAMP_STATES[this.state].color);
    this.color.lerp(this.targetColor, blend);
    this.amount = THREE.MathUtils.lerp(this.amount, active ? 1 : 0, blend);
    // A gentle pulse, not a strobe. Reduced-motion keeps feedback mostly steady.
    const pulse = 1 + Math.sin(time * (event ? 7 : 2.2)) * (event ? 0.12 : 0.035) * motionScale;
    this.material.color.copy(this.color).multiplyScalar(active ? 0.34 : 0.75);
    this.material.emissive.copy(this.color);
    this.material.emissiveIntensity = this.amount * (event ? 1.35 : 0.92) * pulse;
    if (this.shellMaterial) {
      this.shellMaterial.emissive.copy(this.color);
      this.shellMaterial.emissiveIntensity = this.amount * (event ? 0.65 : 0.35) * pulse;
    }
    this.glow.material.color.copy(this.color);
    this.glow.material.opacity = this.amount * (event ? 0.58 : 0.3) * pulse;
    this.glow.scale.setScalar((event ? 0.67 : 0.49) * pulse);
    this.light.color.copy(this.color);
    this.light.intensity = this.amount * (event ? 0.4 : 0.16) * pulse;
    this.mesh.updateWorldMatrix(true, false);
    this.position.copy(this.localCenter);
    this.mesh.localToWorld(this.position);
    this.flightRoot.worldToLocal(this.position);
    this.glow.position.copy(this.position);
    this.light.position.copy(this.position);
  }
}




