import * as THREE from '../vendor/three.module.js';

const smooth = (lo, hi, v) => THREE.MathUtils.smoothstep(v, lo, hi);
const band = (v, a, b, c, d) => smooth(a,b,v) * (1-smooth(c,d,v));
export const PALETTE = {
  orange: new THREE.Color('#ee9419'),
  orangeLight: new THREE.Color('#f9ad35'),
  white: new THREE.Color('#fff9ed'),
  coral: new THREE.Color('#ee7954'),
  belly: new THREE.Color('#ffd399'),
};

// Painted in the rest pose, then stored as mesh vertex colours so it follows the skin.
export function referenceCoatColor(p) {
  const {x,y,z}=p, az=Math.abs(z);
  const c=PALETTE.orange.clone();
  const belly=(1-smooth(-.36,-.22,y))*(1-smooth(.12,.29,az))*(1-smooth(.48,.66,x));
  c.lerp(PALETTE.belly,belly*.72);
  const brow=.035+.20*smooth(.015,.31,az);
  const face=smooth(.70,.91,x)*(1-smooth(brow-.022,brow+.03,y))*(1-smooth(.40,.51,az));
  const ruff=band(x,.25,.41,.66,.79)*band(y,-.39,-.27,.14,.25);
  c.lerp(PALETTE.white,Math.max(face,ruff));
  const ear=smooth(.33,.46,az)*smooth(.13,.31,y)*smooth(.51,.71,x);
  c.lerp(PALETTE.coral,ear*.8);
  const tail=(1-smooth(-.95,-.77,x))*(1-smooth(.09,.17,az));
  c.lerp(PALETTE.coral,tail*.60);
  const blush=Math.exp(-((x-1.04)/.17)**2-((y+.095)/.08)**2-((az-.25)/.085)**2);
  c.lerp(PALETTE.coral,blush*.62*face);
  return c;
}

export const CAPE = Object.freeze({
  anchor: [0.27,0.20,0],
  length: 1.10,
  shoulderWidth: .34,
  hemWidth: .70,
});

// t follows the spine backwards; u crosses the spine symmetrically. No camera-side offset.
export function capePoint(t,u,time,bank=0,flutter=0,motion=1) {
  const edge=Math.abs(u)*2;
  const width=THREE.MathUtils.lerp(CAPE.shoulderWidth,CAPE.hemWidth,Math.sin(t*Math.PI*.5));
  const bend=.095*Math.sin(Math.PI*t);
  const wave=t*t*motion*(.055+.055*flutter)*Math.sin(time*5.8-t*7.0);
  return new THREE.Vector3(
    CAPE.anchor[0]-CAPE.length*t + .055*t*t*edge*edge,
    CAPE.anchor[1]+bend-.025*t-.055*edge*edge+wave,
    CAPE.anchor[2]+u*width - bank*.11*t*t*motion,
  );
}

export const LAMP_SIGNALS = Object.freeze({
  idle: {label:'常亮 · 暖白', color:'#ffd889', intensity:1.5, duration:0},
  reward: {label:'奖励 · 薄荷绿', color:'#55efb0', intensity:3.5, duration:2.8},
  hit: {label:'受击 · 红色', color:'#ff5d63', intensity:2.8, duration:1.6},
  boost: {label:'加速 · 冰蓝', color:'#68cfff', intensity:3.0, duration:2.2},
  off: {label:'尾灯关闭', color:'#665942', intensity:0, duration:0},
});
export function lampPower(mode,age,motion=1) {
  const s=LAMP_SIGNALS[mode] || LAMP_SIGNALS.idle;
  if(mode==='off') return 0;
  if(mode==='idle') return s.intensity*(1+.055*Math.sin(age*1.8)*motion);
  const pulse=.70+.30*Math.sin(age*Math.PI*2*1.35)*motion;
  const release=1-smooth(s.duration-.55,s.duration,age);
  return s.intensity*pulse*release + LAMP_SIGNALS.idle.intensity*(1-release);
}
