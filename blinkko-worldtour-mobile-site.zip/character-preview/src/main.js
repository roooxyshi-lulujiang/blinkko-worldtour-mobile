import * as THREE from "../vendor/three.module.js";
import { GLTFLoader } from "../vendor/GLTFLoader.js";
import { OrbitControls } from "../vendor/OrbitControls.js";
import { paintCharacter, CenterBackCape, TailLamp, LAMP_STATES } from "./character-look.js";

const stage = document.querySelector("#stage");
const loadPanel = document.querySelector("#loading");
const loadError = document.querySelector("#load-error");
const stateLabel = document.querySelector("#state-label");
const pad = document.querySelector("#flight-pad");
const padNub = document.querySelector("#pad-nub");
const bankReadout = document.querySelector("#bank-readout");
const capeReadout = document.querySelector("#cape-readout");

const scene = new THREE.Scene();
scene.background = null;

const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: "high-performance" });
renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.7));
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 0.96;
renderer.shadowMap.enabled = false;
stage.prepend(renderer.domElement);

const camera = new THREE.PerspectiveCamera(31, 1, 0.1, 80);
camera.position.set(0.55, 1.05, -5.45);
camera.lookAt(0, 0.04, 0);

const controls = new OrbitControls(camera, renderer.domElement);
controls.enableDamping = true;
controls.dampingFactor = 0.08;
controls.enablePan = false;
controls.minDistance = 3.2;
controls.maxDistance = 7.8;
controls.minPolarAngle = 0.08;
controls.maxPolarAngle = 1.72;
controls.target.set(0, 0.04, 0);
controls.enabled = false;
controls.saveState();

scene.add(new THREE.HemisphereLight(0xfff7e8, 0xb0a08c, 1.25));
const keyLight = new THREE.DirectionalLight(0xfff5df, 2.1);
keyLight.position.set(-3.0, 4.5, -4.0);
scene.add(keyLight);
const rimLight = new THREE.DirectionalLight(0xffeee0, 0.9);
rimLight.position.set(4, 1.5, 3.0);
scene.add(rimLight);

const groundShadow = new THREE.Mesh(
  new THREE.CircleGeometry(1, 48),
  new THREE.MeshBasicMaterial({ color: 0x415d51, transparent: true, opacity: 0.075, depthWrite: false }),
);
groundShadow.rotation.x = -Math.PI / 2;
groundShadow.position.set(0, -0.82, 0);
groundShadow.scale.set(0.76, 0.2, 1);

const flightRoot = new THREE.Group();
const facingRoot = new THREE.Group();
scene.add(flightRoot);
flightRoot.add(facingRoot);
flightRoot.add(groundShadow);

let lastFrameSeconds = null;
let mixer = null;
let capeRig = null;
let tailLamp = null;
let lastLampState = null;
let lampFeedbackTimer = 0;
const lampReadout = document.querySelector("#lamp-readout");
const lampButtons = [...document.querySelectorAll("[data-lamp-mode]")];
let animationReady = false;
let inspectEnabled = false;
const inspectButton = document.querySelector("#inspect-toggle");
const stageHint = document.querySelector("#stage-hint");
let touchSteer = false;
let targetSteerX = 0;
let targetSteerY = 0;
let steerX = 0;
let steerY = 0;
let roll = null;
let hit = 0;
let capeEnergy = 0;
let elapsed = 0;
let recoveryTimer = 0;
let currentState = "READY TO FLY";
const pressed = new Set();
const gamepadEdges = { roll: false, hit: false, reset: false };
const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)");
let motionScale = reducedMotion.matches ? 0.4 : 1;
reducedMotion.addEventListener?.("change", (event) => {
  motionScale = event.matches ? 0.4 : 1;
});

const gradientBytes = new Uint8Array([
  78, 78, 78, 255,
  144, 144, 144, 255,
  224, 224, 224, 255,
]);
const toonGradient = new THREE.DataTexture(gradientBytes, 3, 1, THREE.RGBAFormat);
toonGradient.magFilter = THREE.NearestFilter;
toonGradient.minFilter = THREE.NearestFilter;
toonGradient.generateMipmaps = false;
toonGradient.colorSpace = THREE.NoColorSpace;
toonGradient.needsUpdate = true;

function boxInLocalSpace(root, worldBox) {
  root.updateWorldMatrix(true, true);
  const localBox = new THREE.Box3().makeEmpty();
  for (const x of [worldBox.min.x, worldBox.max.x]) {
    for (const y of [worldBox.min.y, worldBox.max.y]) {
      for (const z of [worldBox.min.z, worldBox.max.z]) {
        localBox.expandByPoint(root.worldToLocal(new THREE.Vector3(x, y, z)));
      }
    }
  }
  return localBox;
}

function alignForwardAndCenter(gltfRoot) {
  const box = new THREE.Box3().setFromObject(gltfRoot);
  const size = box.getSize(new THREE.Vector3());
  const center = box.getCenter(new THREE.Vector3());
  const maxDimension = Math.max(size.x, size.y, size.z);
  const scale = 2.45 / Math.max(maxDimension, 1e-4);

  gltfRoot.scale.setScalar(scale);
  gltfRoot.position.copy(center).multiplyScalar(-scale);
  gltfRoot.updateWorldMatrix(true, true);

  // The authored Blinko scene faces +Z; the flight rig presents forward along +X.
  facingRoot.quaternion.setFromAxisAngle(new THREE.Vector3(0, 1, 0), Math.PI * 0.5);

  facingRoot.add(gltfRoot);
  gltfRoot.updateWorldMatrix(true, true);
  const alignedBox = new THREE.Box3().setFromObject(gltfRoot);
  const alignedCenter = alignedBox.getCenter(new THREE.Vector3());
  const localAlignedCenter = facingRoot.worldToLocal(alignedCenter.clone());
  gltfRoot.position.sub(localAlignedCenter);
  gltfRoot.updateWorldMatrix(true, true);

  const bodyBoxWorld = new THREE.Box3().setFromObject(gltfRoot);
  // Accessories use flight-root axes; the GLB itself keeps its authored +Z orientation under facingRoot.
  const bodyBox = boxInLocalSpace(flightRoot, bodyBoxWorld);
  return { box: bodyBox };
}

function setState(value) {
  currentState = value;
  stateLabel.textContent = value.toUpperCase();
}

function scheduleFlightRecovery() {
  window.clearTimeout(recoveryTimer);
  setState("RECOVERING");
  recoveryTimer = window.setTimeout(() => {
    if (!touchSteer && !roll && hit < 0.1 && currentState === "RECOVERING") setState("STEADY FLIGHT");
  }, 700);
}

function syncLampReadout() {
  if (!tailLamp || lastLampState === tailLamp.state) return;
  lastLampState = tailLamp.state;
  lampReadout.textContent = LAMP_STATES[tailLamp.state].label;
  lampReadout.dataset.state = tailLamp.state;
  stage.dataset.lampState = tailLamp.state;
  for (const button of lampButtons) button.setAttribute("aria-pressed", String(button.dataset.lampMode === tailLamp.state));
}

function refreshLamp() {
  if (!tailLamp) return;
  tailLamp.update(0.16, elapsed, motionScale);
  syncLampReadout();
  renderer.render(scene, camera);
}

function requestLampEffect(event) {
  if (!tailLamp) return;
  window.clearTimeout(lampFeedbackTimer);
  tailLamp.trigger(event);
  refreshLamp();
  // Real-time deadline + a UI timer avoid stuck feedback when the tab's
  // requestAnimationFrame is suspended. Body/cape physics remain time-capped.
  lampFeedbackTimer = window.setTimeout(refreshLamp, LAMP_STATES[event].duration * 1000 + 30);
}

function setLampBase(state) {
  window.clearTimeout(lampFeedbackTimer);
  tailLamp?.setBase(state);
  refreshLamp();
}

function triggerRoll() {
  if (roll) return;
  window.clearTimeout(recoveryTimer);
  roll = { elapsed: 0, duration: 0.82 };
  setState("BARREL ROLL");
  requestLampEffect("boost");
  capeEnergy = Math.max(capeEnergy, 0.9);
}

function triggerHit() {
  window.clearTimeout(recoveryTimer);
  hit = 1;
  capeEnergy = Math.max(capeEnergy, 0.7);
  setState("IMPACT REACTION");
  requestLampEffect("impact");
  window.setTimeout(() => {
    if (!roll && hit < 0.1) setState("RECOVERING");
  }, 330);
}

function triggerReward() {
  requestLampEffect("reward");
  capeEnergy = Math.max(capeEnergy, 0.45);
}

function triggerBoost() {
  requestLampEffect("boost");
  capeEnergy = Math.max(capeEnergy, 0.8);
}

function resetFlight() {
  window.clearTimeout(recoveryTimer);
  targetSteerX = 0;
  targetSteerY = 0;
  steerX = 0;
  steerY = 0;
  hit = 0;
  roll = null;
  capeEnergy = 0;
  setLampBase("idle");
  pressed.clear();
  flightRoot.position.set(0, 0, 0);
  flightRoot.rotation.set(0, 0, 0);
  padNub.style.transform = "translate(0px, 0px)";
  setState("READY TO FLY");
}

function applyPointerSteer(event) {
  const rect = pad.getBoundingClientRect();
  const radius = Math.min(rect.width, rect.height) * 0.34;
  const dx = event.clientX - (rect.left + rect.width / 2);
  const dy = event.clientY - (rect.top + rect.height / 2);
  const magnitude = Math.hypot(dx, dy);
  const scale = magnitude > radius ? radius / magnitude : 1;
  const x = dx * scale;
  const y = dy * scale;
  targetSteerX = THREE.MathUtils.clamp(x / radius, -1, 1);
  targetSteerY = THREE.MathUtils.clamp(-y / radius, -1, 1);
  padNub.style.transform = `translate(${x}px, ${y}px)`;
}

function applyDeadzone(value, deadzone = 0.14) {
  const magnitude = Math.abs(value);
  return magnitude <= deadzone ? 0 : Math.sign(value) * (magnitude - deadzone) / (1 - deadzone);
}

pad.addEventListener("pointerdown", (event) => {
  touchSteer = true;
  pad.classList.add("dragging");
  pad.setPointerCapture(event.pointerId);
  applyPointerSteer(event);
  setState("STEERING");
});
pad.addEventListener("pointermove", (event) => {
  if (touchSteer) applyPointerSteer(event);
});
function stopPointerSteer() {
  touchSteer = false;
  pad.classList.remove("dragging");
  targetSteerX = 0;
  targetSteerY = 0;
  padNub.style.transform = "translate(0px, 0px)";
  if (!roll && hit < 0.1) scheduleFlightRecovery();
}
pad.addEventListener("pointerup", stopPointerSteer);
pad.addEventListener("pointercancel", stopPointerSteer);

inspectButton.addEventListener("click", () => {
  inspectEnabled = !inspectEnabled;
  controls.enabled = inspectEnabled;
  inspectButton.setAttribute("aria-pressed", String(inspectEnabled));
  stage.classList.toggle("inspect-enabled", inspectEnabled);
  stageHint.textContent = inspectEnabled ? "INSPECT MODE · DRAG TO ROTATE" : "PAD / KEYS · STEER";
  if (inspectEnabled) {
    setState("INSPECTION MODE");
  } else {
    controls.reset();
    setState("STEADY FLIGHT");
  }
});

window.addEventListener("keydown", (event) => {
  const key = event.key.toLowerCase();
  if (["arrowup", "arrowdown", "arrowleft", "arrowright", " "].includes(key)) event.preventDefault();
  pressed.add(key);
  if (["a", "d", "w", "s", "arrowleft", "arrowright", "arrowup", "arrowdown"].includes(key)) setState("STEERING");
  if (!event.repeat) {
    if (key === "f") triggerRoll();
    if (key === "h") triggerHit();
    if (key === "g") triggerReward();
    if (key === "b") triggerBoost();
    if (key === " " || key === "spacebar") resetFlight();
  }
});
window.addEventListener("keyup", (event) => {
  const key = event.key.toLowerCase();
  pressed.delete(key);
  if (!roll && hit < 0.1 && pressed.size === 0) scheduleFlightRecovery();
});
window.addEventListener("blur", () => pressed.clear());
document.querySelector("#roll-button").addEventListener("click", triggerRoll);
document.querySelector("#hit-button").addEventListener("click", triggerHit);
document.querySelector("#reset-button").addEventListener("click", resetFlight);

for (const button of lampButtons) button.addEventListener("click", () => {
  const mode = button.dataset.lampMode;
  if (mode === "reward") triggerReward();
  else if (mode === "impact") triggerHit();
  else if (mode === "boost") triggerBoost();
  else setLampBase(mode);
});

const previewViews = {
  flight: [0.55, 1.05, 5.45], front: [5.5, 0.65, 0],
  back: [-5.5, 1.15, 0], top: [0.08, 5.9, 0.3],
};
for (const button of document.querySelectorAll("[data-view]")) button.addEventListener("click", () => {
  const mode = button.dataset.view;
  camera.position.fromArray(previewViews[mode]);
  controls.target.set(0, 0.02, 0);
  camera.lookAt(controls.target);
  controls.update();
  inspectEnabled = mode !== "flight";
  controls.enabled = inspectEnabled;
  inspectButton.setAttribute("aria-pressed", String(inspectEnabled));
  stage.classList.toggle("inspect-enabled", inspectEnabled);
  stageHint.textContent = inspectEnabled ? "INSPECT MODE · DRAG TO ROTATE" : "PAD / KEYS · STEER";
  for (const viewButton of document.querySelectorAll("[data-view]")) viewButton.setAttribute("aria-pressed", String(viewButton === button));
});

// Preview-only bridge: future game events can use these hooks without changing
// the renderer. No Skytail gameplay or collectable has been wired in this pass.
window.blinkkoPreview = Object.freeze({
  reward: triggerReward, impact: triggerHit, boost: triggerBoost,
  setLampEnabled: (enabled) => setLampBase(enabled ? "idle" : "off"),
});
window.addEventListener("blinkko:reward", triggerReward);
window.addEventListener("blinkko:impact", triggerHit);
window.addEventListener("blinkko:boost", triggerBoost);

function updateFlight(dt) {
  const keyX = (pressed.has("d") || pressed.has("arrowright") ? 1 : 0) -
    (pressed.has("a") || pressed.has("arrowleft") ? 1 : 0);
  const keyY = (pressed.has("w") || pressed.has("arrowup") ? 1 : 0) -
    (pressed.has("s") || pressed.has("arrowdown") ? 1 : 0);
  const gamepad = Array.from(navigator.getGamepads?.() || []).find((item) => item?.connected);
  const gamepadX = gamepad ? applyDeadzone(gamepad.axes[0] || 0) : 0;
  const gamepadY = gamepad ? -applyDeadzone(gamepad.axes[1] || 0) : 0;
  const gamepadRoll = Boolean(gamepad?.buttons[3]?.pressed);
  const gamepadHit = Boolean(gamepad?.buttons[2]?.pressed);
  const gamepadReset = Boolean(gamepad?.buttons[0]?.pressed);
  if (gamepadRoll && !gamepadEdges.roll) triggerRoll();
  if (gamepadHit && !gamepadEdges.hit) triggerHit();
  if (gamepadReset && !gamepadEdges.reset) resetFlight();
  gamepadEdges.roll = gamepadRoll;
  gamepadEdges.hit = gamepadHit;
  gamepadEdges.reset = gamepadReset;
  if (!touchSteer) {
    const keyboardActive = keyX !== 0 || keyY !== 0;
    const gamepadActive = Math.abs(gamepadX) + Math.abs(gamepadY) > 0.04;
    targetSteerX = keyboardActive ? keyX : gamepadX;
    targetSteerY = keyboardActive ? keyY : gamepadY;
    if (keyboardActive || gamepadActive) setState("STEERING");
    else if (!roll && hit < 0.1 && currentState === "STEERING") scheduleFlightRecovery();
  }
  const follow = 1 - Math.exp(-dt * 5.2);
  steerX += (targetSteerX - steerX) * follow;
  steerY += (targetSteerY - steerY) * follow;

  const bob = Math.sin(elapsed * 2.8) * 0.045 * motionScale;
  flightRoot.position.y = steerY * 0.47 + bob - hit * 0.13;
  flightRoot.position.z = -steerX * 0.54;
  const restingBank = -steerX * 0.31;
  const restingPitch = 0.09 + steerY * 0.12 + Math.sin(elapsed * 1.7) * 0.025 * motionScale;

  if (roll) {
    roll.elapsed += dt;
    const t = Math.min(1, roll.elapsed / roll.duration);
    const eased = t * t * (3 - 2 * t);
    flightRoot.rotation.x = restingBank + Math.sin(Math.PI * t) * 0.16 + Math.PI * 2 * eased;
    if (t >= 1) {
      flightRoot.rotation.x = restingBank;
      roll = null;
      setState(hit > 0.1 ? "RECOVERING" : "STEADY FLIGHT");
    }
  } else {
    flightRoot.rotation.x = restingBank;
  }
  flightRoot.rotation.z = restingPitch + hit * 0.15 * Math.sin(elapsed * 24);
  flightRoot.rotation.y = steerX * 0.08;

  hit = Math.max(0, hit - dt * 1.7);
  capeEnergy = Math.max(0, capeEnergy - dt * 0.65);
  if (!roll && hit < 0.03 && currentState === "IMPACT REACTION") setState("RECOVERING");
  if (!roll && hit < 0.03 && currentState === "RECOVERING") setState("STEADY FLIGHT");

  const bankDegrees = Math.round(Math.abs(restingBank) * 57.2958);
  bankReadout.textContent = `${String(bankDegrees).padStart(2, "0")}°`;
  capeReadout.textContent = capeEnergy > 0.45 ? "FLUTTER" : "BREEZY";
  capeRig?.update(elapsed, 0.2 + capeEnergy + Math.abs(steerX) * 0.5 + (roll ? 1 : 0), motionScale);
}

function resize() {
  const rect = stage.getBoundingClientRect();
  if (rect.width <= 0 || rect.height <= 0) return;
  camera.aspect = rect.width / rect.height;
  camera.updateProjectionMatrix();
  renderer.setSize(rect.width, rect.height, false);
}
const resizeObserver = new ResizeObserver(resize);
resizeObserver.observe(stage);
window.addEventListener("resize", resize);

const loader = new GLTFLoader();
loader.load(
  "./assets/Blinko_Classic.glb",
  (gltf) => {
    const character = gltf.scene;
    alignForwardAndCenter(character);
    const paintStats = paintCharacter(character, flightRoot, toonGradient);
    capeRig = new CenterBackCape(character, flightRoot, toonGradient);
    tailLamp = new TailLamp(character, flightRoot);
    stageHint.textContent = "PAD / KEYS · STEER";
    stage.dataset.palette = JSON.stringify(paintStats);
    stage.dataset.capeAnchor = JSON.stringify(capeRig.anchor.toArray());
    stage.dataset.ready = "true";

    // A side-biased flight camera keeps the body readable; cape length must not zoom the hero down.
    camera.position.set(0.55, 1.05, 5.45);
    camera.lookAt(0, 0.02, 0);
    controls.target.set(0, 0.02, 0);
    controls.update();
    controls.saveState();

    if (gltf.animations.length > 0) {
      mixer = new THREE.AnimationMixer(character);
      const action = mixer.clipAction(gltf.animations[0]);
      action.setLoop(THREE.LoopRepeat, Infinity);
      action.timeScale = 0.58;
      action.play();
      animationReady = true;
    }
    loadPanel.classList.add("done");
    window.setTimeout(() => { loadPanel.hidden = true; }, 450);
    setState(animationReady ? "ANIMATED FLIGHT STUDY" : "READY TO FLY");
  },
  undefined,
  (error) => {
    console.error(error);
    const errorMessage = "Blinko model could not be loaded.\n" + (error?.message || "Check that this preview is being served over HTTP.");
    loadError.textContent = errorMessage;
    loadError.hidden = false;
    loadPanel.classList.add("done");
  },
);

function animate() {
  requestAnimationFrame(animate);
  const now = performance.now() * 0.001;
  const dt = lastFrameSeconds === null ? 1 / 60 : THREE.MathUtils.clamp(now - lastFrameSeconds, 0, 0.05);
  lastFrameSeconds = now;
  elapsed += dt;
  mixer?.update(dt);
  // Keep the normalization/paint reference pose deterministic during loading.
  if (tailLamp) updateFlight(dt);
  if (tailLamp) {
    tailLamp.update(dt, elapsed, motionScale);
    syncLampReadout();
  }
  controls.update();
  renderer.render(scene, camera);
}
resize();
animate();

