# Blinkko Character-Only Flight Preview · Revision 04

This review preview does not include or modify the Skytail game world, gameplay, or repository. The supplied GLB and original Blender files are unchanged.

## Run

Double-click run-preview.cmd, or run node serve.mjs in this folder. Open http://127.0.0.1:4180/. All model and runtime assets are local; no network dependency is required.

## Review changes

- Removed the six extra orange cone tufts (the stray fragments in the screenshot).
- Painted the original skinned body with a golden-orange coat, warm-cream face with rounded brow/cheek boundaries, a small upper-neck marking and restrained coral accents. Orange is retained at the ear roots and side of the skull. Vertex colors follow the bones.
- Replaced the side-mounted cape/collar with a symmetric center-back cape and a shoulder seam. Its pinned neckline follows the upper-spine bone; only the free cloth flutters.
- Restored the original tail emitter and a translucent outer sleeve, plus a soft local halo/light. The emitter follows the existing tail bone.

## Controls

WASD / arrows / steering pad: steer. F: roll. H: impact. G: reward. B: boost. Space: reset. Gamepad left stick: steer; Y: roll; X: impact; A: reset.

SIDE / FACE / BACK / TOP: review angles. INSPECT: free orbit.

Tail states: warm idle; green reward (2.8 s); red impact (1.8 s); blue boost (2.8 s); off. Transient effects return to the selected base (warm or off). Feedback pulses become mostly steady with reduced-motion enabled. Reset returns to warm.

## Future integration hooks

The preview exposes window.blinkkoPreview.reward(), impact(), boost(), setLampEnabled(boolean). It also listens for blinkko:reward, blinkko:impact, and blinkko:boost window events.

These hooks are demonstrated here only. Real Skytail collectables/collisions are NOT connected yet.

## Asset boundary

The reference guides color placement, not a fur recreation. This remains a lightweight toon surface, not the original offline particle-fur render. The procedural cape is preview geometry and is not baked into the Blender source.

## Revision 03 · Reference color refinement

The oversized white side-neck band is removed; only a small upper-neck marking remains. The cream face boundary curves around the eyes and cheeks and descends toward the outer edges instead of reaching the ear roots. Cream is warmer (#ffe6c4); the green/blue studio fill was changed to neutral-warm tones. Cape geometry, attachment, animation and tail-light behavior are unchanged.

## Revision 04 · Thin side collar

Restored a narrow warm-cream ring below the ears, following the user-marked curve from the small rear-neck marking to the muzzle. Both sides are symmetric; upper ear roots and the areas above/below the band stay orange. Cream hue, face boundary, cape, lights and animation behavior are unchanged from revision 03.
