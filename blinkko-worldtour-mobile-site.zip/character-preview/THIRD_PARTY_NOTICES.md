# Third-party notices

- **Three.js 0.186.0** — MIT license. The license text is included at
  `vendor/THREE-LICENSE.txt`. The bundled `GLTFLoader`, `OrbitControls`, and
  utility modules are from the same Three.js distribution.
- **Blinko character** — derived only from the user-provided Blinko Blender
  asset through the previously reviewed GLB export. The original `.blend`
  files were not modified.
