# BLINKKO · 世界地标巡游

一款可直接在浏览器游玩的 3D 无限飞行小游戏，支持电脑键盘、鼠标和手机触控。

**在线试玩：** https://roooxyshi-lulujiang.github.io/blinkko-worldtour-mobile/

## 操作方式

- **电脑：** 鼠标或 `WASD` / 方向键飞行；`F` 翻滚；`P` 暂停；`M` 开关声音；`Esc` 返回首页。
- **手机：** 拖动左下摇杆控制飞行，点击右下按钮翻滚；支持竖屏和横屏。
- 收集星星恢复能量，避开炸弹；可切换天气或使用自动天气轮播。

## 页面

- [游戏首页](./)
- [世界地标图鉴](./landmarks.html)
- [手机布局试玩页](./mobile-review.html)
- [角色预览](./character-preview/)

## 许可与来源

仓库保留游戏、字体和第三方组件的许可与归属说明：`LICENSE`、`LICENSE.fonts`、`LICENSE.third-party`。构建来源与版本记录见 [`provenance.json`](./provenance.json)。
